---
name: Research Interests
about: Configure paper search topics
title: Research Interests
labels: config
assignees: ''
---

```json
{
  "sources": [
    { "type": "arxiv", "name": "arXiv" },
    { "type": "openalex", "name": "OpenAlex" },
    { "type": "crossref", "name": "Crossref" }
  ],
  "conference_sources": {
    "enabled": false
  },
  "topics": [
    {
      "id": "cognitive_translation_studies",
      "name": "认知取向的翻译研究",
      "description": "关注认知翻译学、翻译过程研究、译者认知、注意力、工作记忆、认知负荷、翻译单位、问题解决与决策过程，优先筛选可转化为论文变量、指标和实证方法的研究。",
      "keywords": [
        "cognitive translation studies",
        "translation process research",
        "translator cognition",
        "translation cognition",
        "cognitive load in translation",
        "working memory translation",
        "attention in translation",
        "translation decision making",
        "translation problem solving",
        "translation units",
        "eye tracking translation",
        "keystroke logging translation",
        "think aloud protocol translation",
        "process-oriented translation studies"
      ],
      "arxiv_categories": ["cs.CL", "cs.HC", "cs.AI"]
    },
    {
      "id": "narratology_and_translation",
      "name": "叙事学与翻译研究",
      "description": "关注叙事视角、聚焦、声音、时间、情节建构、人物塑造、叙事身份、重述与翻译中的叙事重构，尤其关注叙事学概念如何转化为译文分析指标。",
      "keywords": [
        "narratology and translation",
        "narrative translation",
        "narrative perspective translation",
        "focalization translation",
        "voice in translation",
        "narrative voice translation",
        "narrative time translation",
        "storytelling translation",
        "re-narration translation",
        "narrative framing translation",
        "characterization in translation",
        "fiction translation narratology"
      ],
      "arxiv_categories": ["cs.CL"]
    },
    {
      "id": "cognitive_linguistics_embodied_linguistics",
      "name": "认知语言学与体认语言学",
      "description": "关注概念隐喻、概念整合、框架语义、构式语法、范畴化、意象图式、视角化、突显、体认认知和具身意义建构，并优先保留与翻译分析、文学阐释或语料方法可结合的论文。",
      "keywords": [
        "cognitive linguistics",
        "embodied cognition",
        "embodied linguistics",
        "conceptual metaphor",
        "metaphor translation",
        "conceptual blending",
        "frame semantics",
        "construction grammar",
        "image schema",
        "categorization",
        "construal",
        "perspective taking language",
        "embodied meaning",
        "cognitive poetics"
      ],
      "arxiv_categories": ["cs.CL", "cs.AI"]
    },
    {
      "id": "corpus_based_translation_studies",
      "name": "语料库翻译研究",
      "description": "关注平行语料库、可比语料库、翻译共性、译者风格、翻译规范、词汇语法特征、搭配、关键词、语义韵和语料库辅助文学翻译研究，优先筛选方法清晰、指标可复用的研究。",
      "keywords": [
        "corpus-based translation studies",
        "corpus translation studies",
        "parallel corpus translation",
        "comparable corpus translation",
        "translation universals",
        "translator style",
        "translator stylometry",
        "translation norms corpus",
        "keywords in translation",
        "collocation translation",
        "semantic prosody translation",
        "corpus-assisted literary translation",
        "corpus-based discourse analysis translation"
      ],
      "arxiv_categories": ["cs.CL", "cs.IR", "stat.AP"]
    },
    {
      "id": "ai_machine_translation_translator_studies",
      "name": "AI、机器翻译与译者研究",
      "description": "关注机器翻译、神经机器翻译、大语言模型辅助翻译、译后编辑、人机协同、翻译质量评估、翻译伦理与译者主体性，为投稿时连接数字人文和智能翻译研究保留入口。",
      "keywords": [
        "machine translation",
        "neural machine translation",
        "large language models translation",
        "LLM-assisted translation",
        "computer-assisted translation",
        "post-editing",
        "human machine interaction translation",
        "translation quality assessment",
        "translation evaluation",
        "translator agency",
        "translation technology",
        "AI and translation studies",
        "literary machine translation"
      ],
      "arxiv_categories": ["cs.CL", "cs.AI", "cs.HC"]
    }
  ]
}
```
